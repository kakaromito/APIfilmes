﻿ using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class apiUsuarioController : ApiController
    {
        private db_230110Entities db = new db_230110Entities();

        // GET: api/apiUsuario
        public IQueryable<tb_filme> Gettb_filme()
        {
            return db.tb_filme;
        }

        // GET: api/apiUsuario/5
        [ResponseType(typeof(tb_filme))]
        public async Task<IHttpActionResult> Gettb_filme(long id)
        {
            tb_filme tb_filme = await db.tb_filme.FindAsync(id);
            if (tb_filme == null)
            {
                return NotFound();
            }

            return Ok(tb_filme);
        }

        // PUT: api/apiUsuario/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> Puttb_filme(long id, tb_filme tb_filme)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tb_filme.codFilme)
            {
                return BadRequest();
            }

            db.Entry(tb_filme).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tb_filmeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/apiUsuario
        [ResponseType(typeof(tb_filme))]
        public async Task<IHttpActionResult> Posttb_filme(tb_filme tb_filme)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tb_filme.Add(tb_filme);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = tb_filme.codFilme }, tb_filme);
        }

        // DELETE: api/apiUsuario/5
        [ResponseType(typeof(tb_filme))]
        public async Task<IHttpActionResult> Deletetb_filme(long id)
        {
            tb_filme tb_filme = await db.tb_filme.FindAsync(id);
            if (tb_filme == null)
            {
                return NotFound();
            }

            db.tb_filme.Remove(tb_filme);
            await db.SaveChangesAsync();

            return Ok(tb_filme);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tb_filmeExists(long id)
        {
            return db.tb_filme.Count(e => e.codFilme == id) > 0;
        }
    }
}